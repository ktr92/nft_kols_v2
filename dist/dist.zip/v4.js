
$(document).ready(function(){
    ;(function v4() {
      function setBodyheight() {
        const h =
          $(window).height() -
          $("#footer").height() -
          $("#header").height() -
          $(".navcontent").height()
        $(".vhblock").css("min-height", `${h}px`)
      }
      setBodyheight()

      function showLinkpopup(element) {
        $('[data-toggle="project_link"]').removeClass("active")

        const markpos = element.position().left

        element.siblings('[data-toggle="project_link"]').addClass("active")
        element
          .siblings('[data-toggle="project_link"]')
          .find(".linkpopup__marker")
          .css("left", markpos + "px")
      }

      $("[data-action='addtofav']").on("click", function (e) {
        e.preventDefault()
        $(this).toggleClass("active")
      })
      $("[data-action='getHashtag']").on("click", function (e) {
        e.preventDefault()
        e.stopPropagation()
        if ($(this).hasClass("disabled")) {
          return
        }

        $(this).find(".tablehastag").removeClass("notactive").addClass("active")
        const html = $(this).wrap("<p/>").parent().html()
        $(this).unwrap()
        $(this).hide()
        if (
          $(this).attr("data-type") &&
          $(this).attr("data-type") === "type1"
        ) {
          $('[data-type="type1"]').not($(this)).addClass("disabled")
        }
        $(this)
          .closest(".tableblock__col_hashtags")
          .find(".tablehashtags__selected ul")
          .prepend(html)

        $('[data-toggle="hashtagsblock"]').removeClass("active")
      })
      $("[data-action='hashtagsblock']").on("click", function (e) {
        e.preventDefault()
        $(".hashtagsblock").removeClass("active")

        $(this).toggleClass("active")
        $(this).siblings('[data-toggle="hashtagsblock"]').toggleClass("active")
      })

      $("[data-action='project_link'].unactive").on("click", function (e) {
        e.preventDefault()
        const element = $(this)
        showLinkpopup(element)
      })

      $("body").on("mousedown", "[data-action='project_link']", function (e) {
        document.oncontextmenu = function () {
          return false
        }
        if (e.button == 2) {
          const element = $(this)
          showLinkpopup(element)
          return false
        }
        return true
      })

      function join(date, options, separator) {
        function format(option) {
           let formatter = new Intl.DateTimeFormat('en', option);
           return formatter.format(date);
        }
        return options.map(format).join(separator);
     }

      $('[data-datepicker="datepick"]').on('click', function(e) {
        e.preventDefault()
        $('[data-toggle="datepick"]').removeClass('active')
        $(this).closest('.tableblock__col_notify').find('[data-toggle="datepick"]').toggleClass('active')
      })

      $(".datepick").each(function () {
        const notify = $(this)
        $(this).datetimepicker({
          date: new Date(),
          viewMode: "YMDHMS",
          firstDayOfWeek: 1,
          onOk: function () {
            notify.closest('.tableblock__col_notify').find('[data-toggle="datepick"]').removeClass('active')
          },
          onClear: function(){
            notify.closest('.tableblock__col_notify').find('[data-datepicker="datepick"]').removeClass('chosen')
            notify.closest('.tableblock__col_notify').find('[data-toggle="datepick"]').removeClass('active')
          },
          onDateChange: function () {
            notify.closest('.tableblock__col ').find('.notify').addClass('chosen')
            let options = [{day: 'numeric'}, {month: 'short'}];
            if ( this.getValue()) {
              const date = join(this.getValue(), options, ' ');
              const time = ("0" + this.getValue().getHours()).slice(-2) + ":" + ("0" + this.getValue().getMinutes()).slice(-2);
              notify
                .closest(".tableblock__col")
                .find(".tabledatetime__date")
                .text(date)
              /*   $('#date-text-ymd2').text(this.getText('YYYY-MM-DD')); */
              notify
                .closest(".tableblock__col")
                .find(".tabledatetime__time")
                .text(time)
  
            }
          
          },
        })
       
      })
    })()
})


